﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Shopping_cart.Models;

namespace Shopping_cart.DAL
{
    public class OrderInitializer : System.Data.Entity.DropCreateDatabaseIfModelChanges<OrderContext>
    {
        protected override void Seed(OrderContext context)
        {
            var _users = new List<User>
            {
            new User{ UserID=100, UserName="Raja",PhoneNumber=9987624152,MailID="abc@gmail.com",Pincode=614006,Password="mannai"},
            new User{ UserID=100, UserName="Suryaa",PhoneNumber=8745325445,MailID="Surya@gmail.com",Pincode=614006,Password="Hello1@"},
            new User{ UserID=100, UserName="Ajith",PhoneNumber=9754387652,MailID="Ajith@gmail.com",Pincode=614006,Password="Abc23$"},
            new User{ UserID=100, UserName="Vijay",PhoneNumber=8787654323,MailID="Vijay@gmail.com",Pincode=614006,Password="123!abc"}
            };

            _users.ForEach(s => context.Users.Add(s));
            context.SaveChanges();


            var _Products = new List<Product>
            {
            new Product{ProductID=11,Name="Egg",Price=10 },
            new Product{ProductID=11,Name="Biscut",Price=20 },
            new Product{ProductID=11,Name="Choclate",Price=15 }
            };

            _Products.ForEach(s => context.Products.Add(s));
            context.SaveChanges();

            var _order = new List<Order>
            {
            new Order{ID=1001,Username= "",Productname="", Price=10, Quantity=0, Total=0},

            };

            _order.ForEach(s => context.Orders.Add(s));
            context.SaveChanges();
        }
    }
}