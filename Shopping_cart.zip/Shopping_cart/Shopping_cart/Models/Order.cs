﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data.Entity;

namespace Shopping_cart.Models
{
    public class Order
    {
        public int ID { get; set; }
        public string Username { get; set; }
        public string Productname { get; set; }
        public int Price { get; set; }
        public int Quantity { get; set; }
        public int Total { get; set; }

        public virtual User User { get; set; }
        public virtual Product Product { get; set; }


    }
}